# Production Firebase Authentication & Identity Platform Architecture

A complete, production-grade architectural blueprint for modern Firebase Modular Auth (v10+), Identity Platform security controls, Riverpod Flutter mobile companion integration, blocking Cloud Functions, and Local Emulator Suite prototyping.

## User Review & Critical Decisions

> [!IMPORTANT]
> The architectural design and delivery formats have been confirmed based on your clarifying answers:

- **Confirmed Delivery Format**: Dedicated reference module files created cleanly within the project workspace (`src/guides/auth/`) alongside full architectural documentation.
- **Confirmed Flutter Mobile Architecture**: Flutter 3+ with `flutter_riverpod` using a reactive `StreamProvider<User?>` listening to `authStateChanges()`, integrated with `google_sign_in` and `firebase_auth`.
- **Zero Impact on Existing App**: All guide and reference modules will reside under `src/guides/auth/` without altering or breaking the live Trust educational platform or existing Firebase configuration.

---

## 1. Overview & Core Concept

### What It Delivers
A Senior Staff Engineer reference architecture bridging frontend clients (Web TypeScript & Mobile Flutter) to Firebase Auth and Google Cloud Identity Platform with zero-trust Firestore security rules:

1. **Web Client Architecture (TypeScript / Modular SDK v10+)**:
   - Zero-leak initialization and typed error normalization.
   - Email/password credential flows with client-side regex boundary validations.
   - Google Sign-In with popup/credential negotiation and account-linking guardrails.
   - Reactive unsubscribe lifecycle with memory leak prevention.

2. **Mobile Companion Architecture (Flutter & Riverpod)**:
   - Modern `StreamProvider<User?>` auth state pipeline with automatic widget re-renders.
   - Native Google Sign-In (`google_sign_in`) exchanging `idToken` and `accessToken` for `GoogleAuthProvider.credential`.
   - Async error handling and clean navigation state machine.

3. **Identity Platform & Zero-Trust Security**:
   - Blocking Cloud Functions (`beforeUserCreated` and `beforeUserSignedIn`) using `firebase-functions/v2/identity` to enforce domain whitelists and attach secure claims.
   - Hardened `firestore.rules` validating `request.auth.uid`, token claims, and email verification.

4. **Local Prototyping & CI/CD**:
   - Local Firebase Emulator Suite configuration (`auth`, `firestore`, `functions`) with environment-aware conditional hookup (`connectAuthEmulator`, `connectFirestoreEmulator`).

---

## 2. Technical Architecture & Component Hierarchy

```
┌────────────────────────────────────────────────────────────────────────┐
│                          AUTHENTICATION CLIENTS                        │
├──────────────────────────────────┬─────────────────────────────────────┤
│        Web Client (TS)           │        Flutter Companion App        │
│   (Modular SDK v10+, Strict TS)  │     (flutter_riverpod + Streams)    │
│  - Email/Password Form           │  - AuthStateChanges StreamProvider  │
│  - Google Popup / Credential     │  - GoogleSignIn -> OAuth Credential │
│  - onAuthStateChanged Listener   │  - AsyncValue Reactive UI State     │
└─────────────────┬────────────────┴──────────────────┬──────────────────┘
                  │                                   │
                  ▼                                   ▼
┌────────────────────────────────────────────────────────────────────────┐
│               GOOGLE IDENTITY PLATFORM / FIREBASE AUTH                 │
│  - OAuth 2.0 / OpenID Connect                                          │
│  - Password Hashing (SCRYPT)                                           │
│  - Blocking Cloud Functions Triggers:                                  │
│      * beforeUserCreated: Enforce academic/corporate domain whitelist   │
│      * beforeUserSignedIn: Audit token claims & account standing       │
└─────────────────┬───────────────────────────────────┬──────────────────┘
                  │                                   │
                  ▼                                   ▼
┌─────────────────────────────────────┐ ┌────────────────────────────────┐
│      FIRESTORE SECURITY RULES       │ │  FIREBASE LOCAL EMULATORS      │
│  - Attribute-Based Access Control   │ │  - Auth Emulator (Port 9099)   │
│  - request.auth.uid validation      │ │  - Firestore (Port 8080)       │
│  - Email verification enforcement   │ │  - Functions (Port 5001)       │
│  - Immutable ownership protection   │ │  - Emulator UI (Port 4000)     │
└─────────────────────────────────────┘ └────────────────────────────────┘
```

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Modular Web SDK vs Legacy Namespace**
  - *Chosen Approach*: Tree-shakable Modular SDK (`import { getAuth, signInWithPopup } from 'firebase/auth'`).
  - *Rationale*: Eliminates bundle bloat (reduces bundle size by ~65KB) and aligns with modern Vite/Webpack build pipelines.

- **Decision 2: Flutter Riverpod StreamProvider vs Stateful Widgets**
  - *Chosen Approach*: `StreamProvider<User?>` exposing `AsyncValue<User?>`.
  - *Rationale*: Eliminates boilerplate state synchronization, handles loading/unauthenticated/authenticated transitions declaratively, and guarantees memory disposal.

- **Decision 3: Blocking Functions (2nd Gen) vs Client Validation**
  - *Chosen Approach*: Server-side `beforeUserCreated` blocking trigger via Google Cloud Identity Platform.
  - *Rationale*: Client-side checks can be bypassed by direct API calls; blocking functions execute before the user record is written to the database, ensuring zero unauthorized user creation.

---

## 4. Planned Reference Modules

The implementation will provide complete, production-ready modules under `src/guides/auth/`:

| Module Path | Purpose & Highlights |
|---|---|
| `src/guides/auth/firebase.ts` | Web modular SDK initialization, environment switching (Emulator vs Cloud), and typed instance exports. |
| `src/guides/auth/authService.ts` | Strict TypeScript authentication service (Email/Password, Google Sign-In, reactive state listener, password reset, and normalized error mapping). |
| `src/guides/auth/main.dart` | Complete Flutter companion app code using `flutter_riverpod` (`StreamProvider`, `ConsumerWidget`, Google Sign-In, and responsive state handling). |
| `src/guides/auth/blockingFunctions.ts` | 2nd-gen Identity Platform blocking functions (`beforeUserCreated` domain enforcement and custom claims assignment). |
| `src/guides/auth/firestore.rules` | Hardened security rules with relational owner validation, catch-all default-deny, and immutable user data protection. |
| `src/guides/auth/emulatorConfig.json` | `firebase.json` configuration and setup script for the Firebase Local Emulator Suite. |
| `src/guides/auth/README.md` | Comprehensive Senior Staff engineering guide detailing deployment steps, security checklists, and local test workflows. |

---

## 5. Verification & Safety

- Verify TypeScript compilation using `compile_applet` and linting with `lint_applet`.
- Ensure all existing application features remain fully functional without regressions.

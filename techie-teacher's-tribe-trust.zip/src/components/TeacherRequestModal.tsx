import React, { useState, useEffect } from 'react';
import { TeacherAccessRequest, User } from '../data/db';
import {
  X,
  GraduationCap,
  ShieldCheck,
  Clock,
  CheckCircle2,
  AlertCircle,
  Send,
  FileCheck,
  FileText,
  Loader2,
  Building2,
  Phone,
  Mail,
  Award,
  BookOpen,
  Briefcase
} from 'lucide-react';

interface TeacherRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  teacherRequests: TeacherAccessRequest[];
  verifiedTeacherEmails: string[];
  onSubmitRequest: (
    req: Omit<TeacherAccessRequest, 'id' | 'status' | 'requestedAt'>
  ) => Promise<{
    ok: boolean;
    message: string;
    id?: string;
  }>;
}

export const TeacherRequestModal: React.FC<TeacherRequestModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  teacherRequests,
  verifiedTeacherEmails,
  onSubmitRequest
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [qualifications, setQualifications] = useState('');
  const [college, setCollege] = useState('');
  const [department, setDepartment] = useState('Computer Science & IT');
  const [experienceYears, setExperienceYears] = useState('3+ Years');
  const [subjectsTaught, setSubjectsTaught] = useState('');
  const [classesCanTeach, setClassesCanTeach] = useState('');
  const [professionalBackground, setProfessionalBackground] = useState('');
  const [notes, setNotes] = useState('');

  // Online profile link state (no file uploads permitted)
  const [documentsUrl, setDocumentsUrl] = useState('');
  const [documentsFileName, setDocumentsFileName] = useState('');

  // Submission & feedback state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{
    type: 'success' | 'error';
    message: string;
    applicationId?: string;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setFeedback(null);
      if (currentUser) {
        setName((prev) => prev || currentUser.name || '');
        setEmail((prev) => prev || currentUser.email || '');
        setCollege((prev) => prev || currentUser.college || '');
      }
    }
  }, [isOpen, currentUser]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isSubmitting) onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, isSubmitting, onClose]);

  if (!isOpen) return null;

  const normalizedEmail = email.trim().toLowerCase();
  const isAlreadyVerified = normalizedEmail ? verifiedTeacherEmails.includes(normalizedEmail) : false;
  const existingRequest = normalizedEmail
    ? teacherRequests.find((r) => r.email.trim().toLowerCase() === normalizedEmail)
    : undefined;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    // Field Validations
    if (!name.trim()) {
      setFeedback({ type: 'error', message: 'Please enter your Full Name.' });
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setFeedback({ type: 'error', message: 'Please enter a valid official/faculty email address.' });
      return;
    }
    if (!phone.trim()) {
      setFeedback({ type: 'error', message: 'Please provide a contact phone number.' });
      return;
    }
    if (!college.trim()) {
      setFeedback({ type: 'error', message: 'Please enter your School / College / Institution name.' });
      return;
    }
    if (!qualifications.trim()) {
      setFeedback({ type: 'error', message: 'Please specify your Educational Qualifications (e.g. M.Tech, Ph.D, B.Ed).' });
      return;
    }
    if (!subjectsTaught.trim()) {
      setFeedback({ type: 'error', message: 'Please list the subjects you teach.' });
      return;
    }
    if (!classesCanTeach.trim()) {
      setFeedback({ type: 'error', message: 'Please specify classes/semesters you can teach (e.g. B.Tech Semester 1-8).' });
      return;
    }

    setIsSubmitting(true);
    setFeedback(null);

    try {
      const res = await onSubmitRequest({
        name: name.trim(),
        email: normalizedEmail,
        phone: phone.trim(),
        qualifications: qualifications.trim(),
        college: college.trim(),
        department: department.trim(),
        experienceYears: experienceYears.trim(),
        subjectsTaught: subjectsTaught.trim(),
        classesCanTeach: classesCanTeach.trim(),
        professionalBackground: professionalBackground.trim(),
        documentsUrl: documentsUrl.trim() || undefined,
        documentsFileName: documentsFileName.trim() || undefined,
        notes: notes.trim()
      });

      if (res.ok) {
        setFeedback({
          type: 'success',
          message: res.message,
          applicationId: res.id
        });
      } else {
        setFeedback({ type: 'error', message: res.message });
      }
    } catch (err) {
      console.error('Submission error:', err);
      setFeedback({
        type: 'error',
        message: err instanceof Error ? err.message : 'Database communication error. Please check your connection and retry.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/90 backdrop-blur-md select-none"
      role="dialog"
      aria-modal="true"
      aria-label="Teacher Verification Application Form"
      onClick={onClose}
    >
      <div
        className="bg-black border-4 border-white text-white w-full max-w-3xl max-h-[92vh] overflow-y-auto shadow-[12px_12px_0px_0px_#ffffff] relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 bg-zinc-950 border-b-2 border-white flex items-start justify-between gap-4 sticky top-0 z-20">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono-numbers text-zinc-400 uppercase">
              <GraduationCap className="w-4 h-4 text-white" />
              <span>FACULTY VERIFICATION &amp; TEACHERS TRIBE REGISTRATION</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-heading font-black uppercase mt-1">
              Teacher Verification Application
            </h2>
            <p className="text-xs text-zinc-400 mt-1 max-w-xl">
              Complete your verification profile. Approved educators gain access to the Teachers Portal to author courses, publish handwritten notes, and host live sessions.
            </p>
          </div>
          <button
            onClick={onClose}
            disabled={isSubmitting}
            aria-label="Close modal"
            className="p-1.5 border border-zinc-700 hover:border-white hover:bg-white hover:text-black transition-colors shrink-0 disabled:opacity-40"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Confirmation Screen (if already submitted successfully) */}
        {feedback?.type === 'success' ? (
          <div className="p-8 sm:p-10 space-y-6">
            <div className="p-6 bg-white text-black border-2 border-black shadow-[6px_6px_0px_0px_#ffffff]">
              <div className="flex items-start gap-4">
                <CheckCircle2 className="w-8 h-8 text-black shrink-0 mt-0.5" />
                <div className="space-y-2">
                  <div className="inline-block px-2 py-0.5 bg-black text-white text-[10px] font-mono-numbers font-black uppercase">
                    APPLICATION SUBMITTED TO FIREBASE
                  </div>
                  <h3 className="text-xl sm:text-2xl font-heading font-black uppercase">
                    Verification Application Received!
                  </h3>
                  <p className="text-xs sm:text-sm leading-relaxed font-sans font-medium">
                    {feedback.message}
                  </p>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-300 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono-numbers">
                {feedback.applicationId && (
                  <div>
                    <span className="text-zinc-600 uppercase block text-[10px]">APPLICATION ID:</span>
                    <strong className="text-black text-sm">{feedback.applicationId}</strong>
                  </div>
                )}
                <div>
                  <span className="text-zinc-600 uppercase block text-[10px]">INITIAL STATUS:</span>
                  <strong className="text-amber-800 text-sm">PENDING REVIEW</strong>
                </div>
                <div>
                  <span className="text-zinc-600 uppercase block text-[10px]">VERIFICATION:</span>
                  <strong className="text-zinc-800 text-sm">UNVERIFIED</strong>
                </div>
              </div>
            </div>

            <div className="p-4 bg-zinc-950 border border-zinc-800 text-xs font-mono-numbers text-zinc-400 space-y-2">
              <p className="flex items-center gap-2 text-white font-bold">
                <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Next Steps: Real-Time Admin Panel Delivery</span>
              </p>
              <p>
                Your complete teacher application is now stored in Cloud Firestore and displayed in the Administrator&apos;s real-time review queue. Once approved, you can log in with <strong className="text-white">{email}</strong> to unlock the Teachers Portal.
              </p>
            </div>

            <div className="flex justify-end pt-4">
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 bg-white text-black font-black uppercase text-xs border-2 border-white shadow-[4px_4px_0px_0px_#ffffff] hover:bg-zinc-200 transition-colors"
              >
                Close Window
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
            {/* Live Email Status Indicator */}
            {normalizedEmail && (isAlreadyVerified || existingRequest) && (
              <div
                className={`p-3.5 border-2 text-xs font-mono-numbers flex items-start gap-2.5 ${
                  isAlreadyVerified
                    ? 'bg-emerald-950/50 border-emerald-400 text-emerald-200'
                    : existingRequest?.status === 'PENDING' || existingRequest?.status === 'Pending'
                    ? 'bg-amber-950/50 border-amber-400 text-amber-200'
                    : 'bg-red-950/50 border-red-400 text-red-200'
                }`}
              >
                {isAlreadyVerified ? (
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : existingRequest?.status === 'PENDING' || existingRequest?.status === 'Pending' ? (
                  <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                )}
                <div>
                  {isAlreadyVerified ? (
                    <span>
                      <strong>{normalizedEmail}</strong> is already an <strong>APPROVED TEACHER EMAIL</strong>. Sign in with this account to enter the Teachers Portal!
                    </span>
                  ) : existingRequest?.status === 'PENDING' || existingRequest?.status === 'Pending' ? (
                    <span>
                      A verification request for <strong>{normalizedEmail}</strong> ({existingRequest.id}) is currently <strong>PENDING ADMIN APPROVAL</strong>.
                    </span>
                  ) : (
                    <span>
                      Previous request for <strong>{normalizedEmail}</strong> was rejected. You can update your credentials and re-submit below.
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Error Feedback */}
            {feedback?.type === 'error' && (
              <div className="p-3.5 border-2 text-xs font-mono-numbers flex items-start gap-2.5 bg-red-950/80 border-red-500 text-red-200">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span>{feedback.message}</span>
              </div>
            )}

            {/* SECTION 1: Personal & Contact Information */}
            <div className="space-y-4">
              <div className="text-xs uppercase tracking-widest text-zinc-400 font-mono-numbers flex items-center gap-1.5 pb-2 border-b border-zinc-800">
                <Mail className="w-3.5 h-3.5 text-white" />
                <span>1. Personal &amp; Contact Details</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Dr. Meera Nair"
                    className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Faculty / Official Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (feedback) setFeedback(null);
                    }}
                    placeholder="faculty@university.ac.in"
                    className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white font-mono-numbers"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white font-mono-numbers"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Educational Qualifications *
                  </label>
                  <input
                    type="text"
                    required
                    value={qualifications}
                    onChange={(e) => setQualifications(e.target.value)}
                    placeholder="e.g. Ph.D. in Computer Science / M.Tech (IITD)"
                    className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                  />
                </div>
              </div>
            </div>

            {/* SECTION 2: Academic & Teaching Credentials */}
            <div className="space-y-4">
              <div className="text-xs uppercase tracking-widest text-zinc-400 font-mono-numbers flex items-center gap-1.5 pb-2 border-b border-zinc-800">
                <Building2 className="w-3.5 h-3.5 text-white" />
                <span>2. Institution &amp; Teaching Experience</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    School / College / Institution Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={college}
                    onChange={(e) => setCollege(e.target.value)}
                    placeholder="e.g. Delhi Technological University (DTU) / COEP"
                    className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Teaching Experience *
                  </label>
                  <select
                    value={experienceYears}
                    onChange={(e) => setExperienceYears(e.target.value)}
                    className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-xs text-white font-bold uppercase focus:outline-none focus:border-white"
                  >
                    <option value="1-2 Years">1-2 Years</option>
                    <option value="3-5 Years">3-5 Years</option>
                    <option value="5-10 Years">5-10 Years</option>
                    <option value="10+ Years">10+ Years</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Department / Academic Branch *
                  </label>
                  <input
                    type="text"
                    required
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    placeholder="e.g. Computer Science & Engineering"
                    className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Classes / Semesters You Can Teach *
                  </label>
                  <input
                    type="text"
                    required
                    value={classesCanTeach}
                    onChange={(e) => setClassesCanTeach(e.target.value)}
                    placeholder="e.g. B.Tech Semester 3-6 / M.Tech / 11th-12th"
                    className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Subjects You Teach *
                </label>
                <input
                  type="text"
                  required
                  value={subjectsTaught}
                  onChange={(e) => setSubjectsTaught(e.target.value)}
                  placeholder="e.g. Data Structures & Algorithms, Theory of Computation, Compiler Design"
                  className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                />
              </div>
            </div>

            {/* SECTION 3: Professional Background & Verification Pitch */}
            <div className="space-y-4">
              <div className="text-xs uppercase tracking-widest text-zinc-400 font-mono-numbers flex items-center gap-1.5 pb-2 border-b border-zinc-800">
                <Briefcase className="w-3.5 h-3.5 text-white" />
                <span>3. Professional Background &amp; Materials</span>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Professional Background &amp; Bio
                </label>
                <textarea
                  rows={2}
                  value={professionalBackground}
                  onChange={(e) => setProfessionalBackground(e.target.value)}
                  placeholder="Summarize your academic history, industry positions, or published works..."
                  className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2 text-sm text-white focus:outline-none focus:border-white resize-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                  Verification Pitch / Notes to Administrator
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Ready to upload handwritten semester crash notes and 10-year solved papers."
                  className="w-full bg-zinc-950 border-2 border-zinc-700 px-3 py-2.5 text-sm text-white focus:outline-none focus:border-white"
                />
              </div>
            </div>

            {/* SECTION 4: Academic / Faculty Profile Reference */}
            <div className="space-y-3 p-4 bg-zinc-950 border-2 border-zinc-800">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-widest text-zinc-400 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-white" />
                  <span>Academic / Faculty Profile Reference (Optional)</span>
                </span>
                <span className="text-[10px] text-zinc-500 font-mono-numbers">
                  URL / LINK
                </span>
              </div>

              <div>
                <input
                  type="url"
                  value={documentsUrl}
                  onChange={(e) => {
                    setDocumentsUrl(e.target.value);
                    if (!documentsFileName) setDocumentsFileName('Online Profile Reference');
                  }}
                  placeholder="Paste LinkedIn, Google Scholar, or University Faculty page URL..."
                  className="w-full bg-black border border-zinc-700 px-3 py-2.5 text-xs text-white focus:outline-none focus:border-white font-mono-numbers"
                />
              </div>

              {documentsFileName && (
                <div className="p-2 bg-black border border-emerald-500/80 flex items-center justify-between text-xs font-mono-numbers text-emerald-300">
                  <div className="flex items-center gap-2 truncate">
                    <FileCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span className="truncate">Attached: {documentsFileName}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setDocumentsUrl('');
                      setDocumentsFileName('');
                    }}
                    className="text-zinc-400 hover:text-red-400 ml-2"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-zinc-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
              <span className="text-[11px] text-zinc-400 font-mono-numbers">
                Applications are delivered to the Trust Admin Panel in real time.
              </span>

              <div className="flex items-center justify-end gap-3">
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={onClose}
                  className="px-4 py-2.5 border border-zinc-700 text-xs font-bold uppercase hover:border-white transition-colors disabled:opacity-40"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isSubmitting || isAlreadyVerified || existingRequest?.status === 'PENDING' || existingRequest?.status === 'Pending'}
                  className="px-6 py-2.5 bg-white text-black font-black uppercase text-xs hover:bg-zinc-200 transition-colors border-2 border-white shadow-[3px_3px_0px_0px_#ffffff] flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-black" />
                      <span>Saving to Firebase...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Submit Verification Application</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

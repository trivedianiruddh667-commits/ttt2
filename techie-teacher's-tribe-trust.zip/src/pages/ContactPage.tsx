import React, { useState } from 'react';
import { SloganBanner } from '../components/SloganBanner';
import {
  MessageSquare,
  Phone,
  Mail,
  Send,
  CheckCircle2,
  MapPin,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Copy,
  Check,
  Loader2,
  Star,
  Award,
  BookOpen,
  Zap,
  Users
} from 'lucide-react';
import { QuerySubmission, User, Course, VerifiedTeacherProfile, CourseReview } from '../data/db';
import { SiteContent } from '../data/siteContent';
import { copyTextSafely } from '../lib/downloadUtils';
import { saveCourseReviewToCloud } from '../lib/firestoreSync';
import { QUICK_LEARNING_MODULES, getAllTeachersRatingList } from '../lib/ratings';

interface ContactPageProps {
  content?: SiteContent['contact'];
  siteContent?: SiteContent;
  courses?: Course[];
  teacherProfiles?: VerifiedTeacherProfile[];
  currentUser?: User | null;
  onAddQuery: (query: QuerySubmission) => Promise<void> | void;
  onAddReview?: (review: CourseReview) => void;
  onNotify?: (msg: string, variant?: 'success' | 'error' | 'info') => void;
}

const DEFAULT_CONTACT: SiteContent['contact'] = {
  header: {
    badge: 'DIRECT STUDENT DESK',
    title: 'Contact & Academic SOS',
    description:
      'Have a question regarding syllabus modules, notes delivery via Blinkit/Zepto, or need custom university coverage? We respond within 30 minutes.'
  },
  sosDirectLineTitle: 'Instant WhatsApp Faculty Hotline',
  sosDirectLineSub: 'Direct peer connection with our subject convenor. Operational 24/7 during exam weeks.',
  phone1: '+91 7985539462 (SOS Exam Desk)',
  phone2: '+91 9343286865 (Faculty Line)',
  emailSupport: 'ajayacademy@zohomail.in',
  emailGrievance: 'trivedianiruddh667@gmail.com',
  officeAddress: "Techie Teacher's Tribe Trust, Block B, Technology Incubator Park, New Delhi 110016",
  officeHours: 'Monday - Friday: 3:00PM-10:00PM (24/7 during End-Term Weeks)',
  faqs: [
    {
      question: 'How quickly are handwritten notes delivered to my hostel?',
      answer:
        'Through our partnerships with Blinkit and Zepto, physical spiral-bound booklets reach campus hostel gates in 10 minutes flat across 40+ engineering college zones.'
    },
    {
      question: 'Are digital course videos downloadable for offline viewing?',
      answer:
        'Yes! Once enrolled in any fast-track sprint or full syllabus module, you can access materials seamlessly via the Student Dashboard on desktop or mobile.'
    },
    {
      question: 'What if my university syllabus has unique derivations?',
      answer:
        'Drop a query right here or ping us on WhatsApp with your syllabus code. Our faculty team reviews and adds custom derivation sheets within 48 hours.'
    }
  ]
};

export const ContactPage: React.FC<ContactPageProps> = ({
  content = DEFAULT_CONTACT,
  siteContent,
  courses = [],
  teacherProfiles = [],
  currentUser,
  onAddQuery,
  onAddReview,
  onNotify
}) => {
  // 1. Query System State
  const [studentName, setStudentName] = useState(currentUser?.name || '');
  const [contactNumber, setContactNumber] = useState('');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [queryText, setQueryText] = useState('');
  const [branch, setBranch] = useState('Computer Science & IT');
  const [submittedQuery, setSubmittedQuery] = useState<QuerySubmission | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [expandedFaqIndex, setExpandedFaqIndex] = useState<number | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // 2. Separate Rating System State
  const [ratingStudentName, setRatingStudentName] = useState(currentUser?.name || '');
  const [ratingEmail, setRatingEmail] = useState(currentUser?.email || '');
  const [ratingBranch, setRatingBranch] = useState('Computer Science & IT');
  const [ratingCategory, setRatingCategory] = useState<'teacher' | 'course' | 'quickLearning'>('teacher');
  const [selectedTargetId, setSelectedTargetId] = useState('');
  const [ratingValue, setRatingValue] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [ratingFeedback, setRatingFeedback] = useState('');
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);
  const [ratingSuccess, setRatingSuccess] = useState<{
    targetName: string;
    rating: number;
    category: string;
  } | null>(null);
  const [ratingError, setRatingError] = useState<string | null>(null);

  // Available Teachers compiled from SiteContent, Core Teachers and Verified Profiles
  const allTeachers = React.useMemo(() => {
    if (siteContent) {
      return getAllTeachersRatingList(siteContent, teacherProfiles, []);
    }
    return [
      { key: 'ajay_kalki', name: 'Ajay "Techie" Kalki', role: 'Founder & Tribe Architect' },
      { key: 'alok_verma', name: 'Prof. Alok Verma', role: 'Lead Mentor · Algorithms' },
      { key: 'sneha_iyer', name: 'Dr. Sneha Iyer', role: 'Senior Academician · Mathematics' },
      { key: 'kabir_rao', name: 'Prof. Kabir Rao', role: 'Hardware Systems Lead' },
      { key: 'nandini_sen', name: 'Dr. Nandini Sen', role: 'Systems Mentor · Databases' },
      { key: 'priya_desai', name: 'Er. Priya Desai', role: 'Network Specialist' },
      { key: 'aniruddh_trivedi', name: 'Aniruddh Trivedi', role: 'Website Designer and Administrator' },
      { key: 'aryan_yadav', name: 'Aryan Yadav', role: 'Researcher and Content Organiser' }
    ];
  }, [siteContent, teacherProfiles]);

  const approvedCourses = React.useMemo(() => courses.filter((c) => c.isApproved), [courses]);

  // Set initial target when switching category
  React.useEffect(() => {
    if (ratingCategory === 'teacher' && allTeachers.length > 0 && !selectedTargetId) {
      setSelectedTargetId(allTeachers[0].name);
    } else if (ratingCategory === 'course' && approvedCourses.length > 0 && !selectedTargetId) {
      setSelectedTargetId(approvedCourses[0].id);
    } else if (ratingCategory === 'quickLearning' && !selectedTargetId) {
      setSelectedTargetId(QUICK_LEARNING_MODULES[0].id);
    }
  }, [ratingCategory, allTeachers, approvedCourses, selectedTargetId]);

  const phoneDigits = '919813881369';
  const waPhone = '919813881369';
  const waHref = `https://wa.me/${waPhone}?text=${encodeURIComponent(
    "Hi Techie Teacher's Tribe Trust, I have a question regarding my semester notes/courses."
  )}`;

  const handleCopy = async (label: string, val: string) => {
    const ok = await copyTextSafely(val);
    if (ok) {
      setCopiedField(label);
      onNotify?.(`${label} copied to clipboard.`, 'success');
      setTimeout(() => setCopiedField(null), 2000);
    }
  };

  // Pure Query Submission Handler
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    const cleanName = studentName.trim();
    const cleanPhone = contactNumber.trim();
    const cleanEmail = email.trim();
    const cleanQuery = queryText.trim();

    if (cleanName.length < 2) {
      setSubmitError('Please enter your full name.');
      return;
    }
    if (cleanPhone.replace(/[^0-9]/g, '').length < 8) {
      setSubmitError('Please enter a valid 10-digit contact number.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setSubmitError('Please enter a valid email address.');
      return;
    }
    if (cleanQuery.length < 10) {
      setSubmitError('Please describe your query in at least 10 characters.');
      return;
    }

    const newQuery: QuerySubmission = {
      id: `QRY-${Date.now().toString().slice(-5)}`,
      studentName: cleanName,
      contactNumber: cleanPhone,
      email: cleanEmail,
      query: `[Branch: ${branch}] ${cleanQuery}`,
      timestamp: new Date().toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit'
      }),
      status: 'Received',
      applicantUid: currentUser?.id
    };

    setIsSubmitting(true);
    try {
      await onAddQuery(newQuery);
      setSubmittedQuery(newQuery);
      setQueryText('');
      onNotify?.('Your academic query has been submitted to the Faculty Desk.', 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Could not dispatch query right now. Please try again.';
      setSubmitError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Separate Rating & Review Submission Handler
  const handleRatingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRatingError(null);

    const cleanName = ratingStudentName.trim();
    const cleanFeedback = ratingFeedback.trim();

    if (cleanName.length < 2) {
      setRatingError('Please provide your name.');
      return;
    }
    if (cleanFeedback.length < 5) {
      setRatingError('Please share a short review or feedback comment (at least 5 characters).');
      return;
    }

    let targetName = '';
    let targetId = '';
    if (ratingCategory === 'teacher') {
      const t = allTeachers.find((item) => item.name === selectedTargetId) || allTeachers[0];
      targetName = t?.name || 'Faculty Member';
      targetId = t?.name || 'teacher';
    } else if (ratingCategory === 'course') {
      const c = approvedCourses.find((item) => item.id === selectedTargetId) || approvedCourses[0];
      targetName = c ? `${c.code}: ${c.title}` : 'Course';
      targetId = c?.id || 'course';
    } else if (ratingCategory === 'quickLearning') {
      const ql = QUICK_LEARNING_MODULES.find((m) => m.id === selectedTargetId) || QUICK_LEARNING_MODULES[0];
      targetName = ql?.title || 'Quick Learning Module';
      targetId = ql?.id || 'ql-3hr';
    }

    setIsSubmittingRating(true);
    try {
      // 1. If rating a course, record CourseReview
      if (ratingCategory === 'course' && targetId) {
        const newReview: CourseReview = {
          id: `REV-${Date.now().toString().slice(-6)}`,
          courseId: targetId,
          studentId: currentUser?.id || `anon_${Date.now()}`,
          studentName: cleanName,
          studentCollege: currentUser?.college || undefined,
          studentBranch: ratingBranch || undefined,
          rating: ratingValue,
          comment: cleanFeedback,
          createdAt: new Date().toLocaleDateString('en-IN', {
            day: 'numeric',
            month: 'short',
            year: 'numeric'
          }),
          verifiedCompletion: true,
          helpfulCount: 0,
          helpfulVoterIds: []
        };
        onAddReview?.(newReview);
        saveCourseReviewToCloud(newReview).catch((err) =>
          console.error('Failed to sync course review to Firestore:', err)
        );
      }

      // 2. Also register into query/rating log for live dynamic rating calculations
      const ratingRecord: QuerySubmission = {
        id: `RATE-${Date.now().toString().slice(-6)}`,
        studentName: cleanName,
        contactNumber: 'RATING-DIRECT',
        email: ratingEmail.trim() || currentUser?.email || 'student@techieteachertribe.org',
        query: `[Direct Student Rating: ${ratingValue}★] ${ratingCategory.toUpperCase()}: ${targetName} — "${cleanFeedback}"`,
        timestamp: new Date().toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
          hour: '2-digit',
          minute: '2-digit'
        }),
        status: 'Received',
        applicantUid: currentUser?.id,
        ratingCategory,
        targetId,
        targetName,
        rating: ratingValue,
        feedbackText: cleanFeedback
      };
      await onAddQuery(ratingRecord);

      setRatingSuccess({
        targetName,
        rating: ratingValue,
        category: ratingCategory === 'teacher' ? 'Faculty Member' : ratingCategory === 'course' ? 'Course' : 'Module'
      });
      setRatingFeedback('');
      onNotify?.(`Rating of ${ratingValue}.0★ submitted for ${targetName}!`, 'success');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Could not submit rating. Please try again.';
      setRatingError(msg);
    } finally {
      setIsSubmittingRating(false);
    }
  };

  return (
    <div className="w-full bg-black text-white select-none">
      {/* Header section */}
      <section className="border-b-2 border-white py-16 px-4 sm:px-6 lg:px-8 bg-zinc-950">
        <div className="max-w-7xl mx-auto">
          <span className="text-xs uppercase tracking-[0.3em] text-zinc-400 font-mono-numbers">
            {content.header.badge}
          </span>
          <h1 className="text-4xl sm:text-6xl font-heading font-black tracking-tight uppercase mt-2">
            {content.header.title}
          </h1>
          <p className="text-zinc-400 text-sm sm:text-base mt-3 max-w-xl">
            {content.header.description}
          </p>
        </div>
      </section>

      {/* Main Contact Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Column: Direct Communication Channels */}
          <div className="lg:col-span-5 space-y-8">
            <div>
              <span className="text-xs uppercase tracking-widest text-zinc-400 font-mono-numbers">
                INSTANT REACH
              </span>
              <h2 className="text-2xl sm:text-3xl font-heading font-black uppercase mt-1">
                {content.sosDirectLineTitle}
              </h2>
              <p className="text-xs sm:text-sm text-zinc-400 mt-2 leading-relaxed">
                {content.sosDirectLineSub}
              </p>
            </div>

            {/* WhatsApp Click-to-Chat Button */}
            <a
              href={waHref}
              target="_blank"
              rel="noreferrer"
              className="p-6 border-4 border-white bg-white text-black flex items-center justify-between group shadow-[6px_6px_0px_0px_#ffffff] hover:bg-zinc-200 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-black text-white flex items-center justify-center border border-black shrink-0">
                  <MessageSquare className="w-6 h-6" />
                </div>
                <div>
                  <div className="text-xs font-mono-numbers font-black uppercase text-zinc-600">
                    CLICK TO CHAT
                  </div>
                  <div className="font-heading font-black text-lg uppercase">
                    WhatsApp Faculty Desk
                  </div>
                  <div className="text-xs font-mono-numbers text-zinc-700">
                    +91 9813881369 (SOS Exam Desk)
                  </div>
                </div>
              </div>
              <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform shrink-0" />
            </a>

            {/* Phone & Email Cards */}
            <div className="space-y-4">
              <div className="p-6 border-2 border-white bg-zinc-950 flex items-start justify-between gap-3">
                <div className="flex items-start gap-4 min-w-0">
                  <div className="w-10 h-10 border border-white bg-black flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs uppercase tracking-wider text-zinc-400 font-mono-numbers">
                      CAMPUS HELPLINE NUMBER
                    </div>
                    <div className="text-sm sm:text-base font-bold text-white font-mono-numbers mt-0.5 flex flex-wrap gap-x-2">
                      <a href="tel:+917985539462" className="hover:underline">
                        +91 7985539462 (SOS Exam Desk) / +91 9343286865 (Faculty Line)
                      </a>
                    </div>
                    <div className="text-xs text-zinc-500 mt-1">
                      Operating Hours: Monday - Friday: 3:00PM-10:00PM (24/7 during End-Term Weeks)
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('Phone', '+91 7985539462 / +91 9343286865')}
                  aria-label="Copy helpline number"
                  className="min-h-[44px] min-w-[44px] p-2 border border-zinc-800 hover:border-white text-zinc-400 hover:text-white flex items-center justify-center shrink-0"
                >
                  {copiedField === 'Phone' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <div className="p-6 border-2 border-white bg-zinc-950 flex items-start justify-between gap-3">
                <div className="flex items-start gap-4 min-w-0">
                  <div className="w-10 h-10 border border-white bg-black flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs uppercase tracking-wider text-zinc-400 font-mono-numbers">
                      OFFICIAL QUERY EMAIL
                    </div>
                    <a
                      href="mailto:ajayacademy@zohomail.in"
                      className="text-sm sm:text-base font-bold text-white font-mono-numbers mt-0.5 block truncate hover:underline"
                    >
                      ajayacademy@zohomail.in
                    </a>
                    <div className="text-xs text-zinc-500 mt-1 truncate">
                      Grievance:{' '}
                      <a href="mailto:trivedianiruddh667@gmail.com" className="hover:text-white hover:underline">
                        trivedianiruddh667@gmail.com
                      </a>
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy('Email', 'ajayacademy@zohomail.in')}
                  aria-label="Copy official email"
                  className="min-h-[44px] min-w-[44px] p-2 border border-zinc-800 hover:border-white text-zinc-400 hover:text-white flex items-center justify-center shrink-0"
                >
                  {copiedField === 'Email' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <div className="p-6 border-2 border-zinc-800 bg-black flex items-start gap-4">
                <div className="w-10 h-10 border border-zinc-700 bg-zinc-900 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-zinc-400 font-mono-numbers">
                    REGISTERED ACADEMIC TRUST
                  </div>
                  <div className="text-sm font-semibold text-zinc-300 mt-0.5">
                    {content.officeAddress}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Query Form & Rate System */}
          <div className="lg:col-span-7 space-y-8">
            {/* 1. Dedicated Query Form */}
            <div className="p-8 sm:p-10 border-4 border-white bg-zinc-950 shadow-[10px_10px_0px_0px_#ffffff]">
              <div className="mb-6">
                <span className="text-xs uppercase tracking-widest text-zinc-400 font-mono-numbers">
                  STUDENT DISPATCH
                </span>
                <h3 className="text-2xl sm:text-3xl font-heading font-black uppercase mt-1">
                  Send Your Query
                </h3>
                <p className="text-xs text-zinc-400 mt-1">
                  Submissions are synced to the Admin SOS Desk ({content.emailSupport}) and prioritized by academic urgency.
                </p>
              </div>

              {submitError && (
                <div className="mb-6 p-4 border-2 border-red-500 bg-red-950/80 text-red-200 flex items-start gap-3 text-xs font-mono-numbers">
                  <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                  <span>{submitError}</span>
                </div>
              )}

              {submittedQuery && (
                <div className="mb-6 p-4 border-2 border-white bg-black flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <div className="font-bold text-white uppercase font-mono-numbers">
                      QUERY DISPATCHED · REF: {submittedQuery.id}
                    </div>
                    <div className="text-zinc-400 mt-0.5">
                      Thank you, {submittedQuery.studentName}. Your query has been saved to our Faculty Desk queue. We will reach back on {submittedQuery.contactNumber} / {submittedQuery.email}.
                    </div>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                      Student Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      placeholder="Your Full Name"
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                      Contact Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={contactNumber}
                      onChange={(e) => setContactNumber(e.target.value)}
                      placeholder="+91 98765 43210"
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white font-mono-numbers transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="student@college.edu"
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white font-mono-numbers transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                      Department / Branch
                    </label>
                    <select
                      value={branch}
                      onChange={(e) => setBranch(e.target.value)}
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white uppercase font-bold"
                    >
                      <option value="Computer Science & IT">Computer Science & IT</option>
                      <option value="Electronics & Communication">Electronics & Communication</option>
                      <option value="Mechanical & Civil">Mechanical & Civil</option>
                      <option value="Applied Sciences & Math">Applied Sciences & Math</option>
                      <option value="General Query">General / Other</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Your Query / Syllabus Details *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={queryText}
                    onChange={(e) => setQueryText(e.target.value)}
                    placeholder="Describe your subject question, university name, or notes requirement..."
                    className="w-full bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="min-h-[48px] w-full py-4 bg-white text-black font-black uppercase tracking-wider text-xs sm:text-sm hover:bg-zinc-200 transition-colors flex items-center justify-center gap-2 border-2 border-white shadow-[4px_4px_0px_0px_#ffffff] disabled:opacity-50"
                >
                  {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  <span>{isSubmitting ? 'Dispatching Query...' : 'Submit Query to Faculty Desk'}</span>
                </button>
              </form>
            </div>

            {/* 2. Separate Dedicated Rate System */}
            <div className="p-8 sm:p-10 border-4 border-white bg-zinc-950 shadow-[10px_10px_0px_0px_#ffffff]">
              <div className="mb-6">
                <span className="text-xs uppercase tracking-widest text-zinc-400 font-mono-numbers">
                  STUDENT EVALUATION & REVIEWS
                </span>
                <h3 className="text-2xl sm:text-4xl font-heading font-black uppercase mt-1">
                  Rate
                </h3>
                <p className="text-xs text-zinc-400 mt-1">
                  Evaluate faculty mentors, semester crash courses, and sprint revision notes to help maintain university benchmarks.
                </p>
              </div>

              {ratingSuccess && (
                <div className="mb-6 p-4 border-2 border-emerald-400 bg-emerald-950/80 text-emerald-200 flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="text-xs">
                    <div className="font-bold text-white uppercase font-mono-numbers">
                      RATING PUBLISHED · {ratingSuccess.rating}.0 ★ FOR {ratingSuccess.targetName}
                    </div>
                    <div className="text-emerald-300 mt-0.5">
                      Thank you for reviewing {ratingSuccess.targetName}. Your evaluation has been factored into the platform's live quality index.
                    </div>
                  </div>
                </div>
              )}

              {ratingError && (
                <div className="mb-6 p-4 border-2 border-red-500 bg-red-950/80 text-red-200 flex items-start gap-3 text-xs font-mono-numbers">
                  <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                  <span>{ratingError}</span>
                </div>
              )}

              <form onSubmit={handleRatingSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                      Student Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={ratingStudentName}
                      onChange={(e) => setRatingStudentName(e.target.value)}
                      placeholder="Your Full Name"
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                      Engineering Branch / Stream
                    </label>
                    <select
                      value={ratingBranch}
                      onChange={(e) => setRatingBranch(e.target.value)}
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-white uppercase font-bold"
                    >
                      <option value="Computer Science & IT">Computer Science & IT</option>
                      <option value="Electronics & Communication">Electronics & Communication</option>
                      <option value="Mechanical & Civil">Mechanical & Civil</option>
                      <option value="Applied Sciences & Math">Applied Sciences & Math</option>
                      <option value="General Engineering">General / Other</option>
                    </select>
                  </div>
                </div>

                {/* Category selector */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-2">
                    Select What You Are Rating *
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setRatingCategory('teacher');
                        if (allTeachers.length > 0) setSelectedTargetId(allTeachers[0].name);
                      }}
                      className={`p-3 border text-left text-xs font-mono-numbers font-bold uppercase transition-colors flex items-center gap-2 ${
                        ratingCategory === 'teacher'
                          ? 'border-white bg-white text-black'
                          : 'border-zinc-800 bg-black text-zinc-400 hover:border-zinc-600 hover:text-white'
                      }`}
                    >
                      <Users className="w-4 h-4 shrink-0" />
                      <span className="truncate">Faculty & Mentors</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setRatingCategory('course');
                        if (approvedCourses.length > 0) setSelectedTargetId(approvedCourses[0].id);
                      }}
                      className={`p-3 border text-left text-xs font-mono-numbers font-bold uppercase transition-colors flex items-center gap-2 ${
                        ratingCategory === 'course'
                          ? 'border-white bg-white text-black'
                          : 'border-zinc-800 bg-black text-zinc-400 hover:border-zinc-600 hover:text-white'
                      }`}
                    >
                      <BookOpen className="w-4 h-4 shrink-0" />
                      <span className="truncate">Courses</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setRatingCategory('quickLearning');
                        setSelectedTargetId(QUICK_LEARNING_MODULES[0].id);
                      }}
                      className={`p-3 border text-left text-xs font-mono-numbers font-bold uppercase transition-colors flex items-center gap-2 ${
                        ratingCategory === 'quickLearning'
                          ? 'border-white bg-white text-black'
                          : 'border-zinc-800 bg-black text-zinc-400 hover:border-zinc-600 hover:text-white'
                      }`}
                    >
                      <Zap className="w-4 h-4 shrink-0" />
                      <span className="truncate">Quick Learning</span>
                    </button>
                  </div>
                </div>

                {/* Target Select Dropdown */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    {ratingCategory === 'teacher' && 'Select Faculty Member *'}
                    {ratingCategory === 'course' && 'Select University Course *'}
                    {ratingCategory === 'quickLearning' && 'Select Quick Learning Module *'}
                  </label>

                  {ratingCategory === 'teacher' && (
                    <select
                      value={selectedTargetId}
                      onChange={(e) => setSelectedTargetId(e.target.value)}
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white font-mono-numbers"
                    >
                      {allTeachers.map((t) => (
                        <option key={t.key} value={t.name}>
                          {t.name} · {t.role}
                        </option>
                      ))}
                    </select>
                  )}

                  {ratingCategory === 'course' && (
                    <select
                      value={selectedTargetId}
                      onChange={(e) => setSelectedTargetId(e.target.value)}
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white font-mono-numbers"
                    >
                      {approvedCourses.map((c) => (
                        <option key={c.id} value={c.id}>
                          [{c.code}] {c.title} — {c.teacher} ({c.branch})
                        </option>
                      ))}
                    </select>
                  )}

                  {ratingCategory === 'quickLearning' && (
                    <select
                      value={selectedTargetId}
                      onChange={(e) => setSelectedTargetId(e.target.value)}
                      className="w-full min-h-[44px] bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white font-mono-numbers"
                    >
                      {QUICK_LEARNING_MODULES.map((m) => (
                        <option key={m.id} value={m.id}>
                          [{m.badge}] {m.title} (~{m.fastTrackMinutes}m)
                        </option>
                      ))}
                    </select>
                  )}
                </div>

                {/* Interactive 5-Star Rating Selector */}
                <div className="p-4 border-2 border-zinc-700 bg-black flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="text-[11px] uppercase font-mono-numbers text-zinc-400 font-bold">
                      YOUR SCORE (1 TO 5 STARS)
                    </div>
                    <div className="flex items-center gap-1.5 mt-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setRatingValue(star)}
                          className="p-1 hover:scale-125 transition-transform cursor-pointer focus:outline-none"
                          aria-label={`Rate ${star} star`}
                        >
                          <Star
                            className={`w-7 h-7 transition-colors ${
                              (hoverRating || ratingValue) >= star
                                ? 'fill-white text-white'
                                : 'text-zinc-700 hover:text-zinc-500'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="sm:text-right">
                    <span className="inline-block bg-white text-black font-black text-xs px-3 py-1.5 font-mono-numbers uppercase">
                      {ratingValue}.0 ★{' '}
                      {ratingValue === 5
                        ? 'EXCEPTIONAL'
                        : ratingValue === 4
                        ? 'VERY GOOD'
                        : ratingValue === 3
                        ? 'GOOD'
                        : ratingValue === 2
                        ? 'FAIR'
                        : 'POOR'}
                    </span>
                    <div className="text-[10px] text-zinc-500 font-mono-numbers mt-1">
                      Factored into live teacher & course ratings
                    </div>
                  </div>
                </div>

                {/* Feedback Comment */}
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                    Your Review / Exam Feedback *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={ratingFeedback}
                    onChange={(e) => setRatingFeedback(e.target.value)}
                    placeholder="Share how this teacher or course helped your exam preparations..."
                    className="w-full bg-black border-2 border-zinc-700 px-3.5 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-white transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmittingRating}
                  className="min-h-[48px] w-full py-4 bg-white text-black font-black uppercase tracking-wider text-xs sm:text-sm hover:bg-zinc-200 transition-colors flex items-center justify-center gap-2 border-2 border-white shadow-[4px_4px_0px_0px_#ffffff] disabled:opacity-50"
                >
                  {isSubmittingRating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Star className="w-4 h-4 fill-black" />}
                  <span>{isSubmittingRating ? 'Publishing Rating...' : 'Submit Rating & Review'}</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions Section (Editable via CMS) */}
      {content.faqs && content.faqs.length > 0 && (
        <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 border-t-2 border-white">
          <div className="text-center mb-10">
            <span className="text-xs uppercase tracking-widest text-zinc-400 font-mono-numbers">
              FREQUENTLY ASKED
            </span>
            <h3 className="text-2xl sm:text-4xl font-heading font-black uppercase mt-1">
              Campus Queries Answered
            </h3>
          </div>

          <div className="space-y-4">
            {content.faqs.map((faq, idx) => {
              const isOpen = expandedFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className="border-2 border-white bg-zinc-950 transition-colors shadow-[4px_4px_0px_0px_#ffffff]"
                >
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    onClick={() => setExpandedFaqIndex(isOpen ? null : idx)}
                    className="min-h-[48px] w-full p-5 text-left flex items-center justify-between gap-4 font-heading font-bold text-sm sm:text-base uppercase"
                  >
                    <span>{faq.question}</span>
                    {isOpen ? (
                      <ChevronUp className="w-5 h-5 shrink-0 text-white" />
                    ) : (
                      <ChevronDown className="w-5 h-5 shrink-0 text-zinc-400" />
                    )}
                  </button>
                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-zinc-300 border-t border-zinc-800 leading-relaxed font-normal">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Slogan Banner */}
      <SloganBanner
        variant="standard"
        slogan="From Notes to Knowledge."
        subtext="Every query answered by senior educators, not automated bots."
      />
    </div>
  );
};
